package com.gabrielzevedo.comandaeletronica;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ItemListaComanda extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_lista_comanda);
    }
}
